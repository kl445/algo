package com.rest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

//Get: http://localhost:8080/rest/users
//@RestConroller=@Controller +@ResponseBody(java->json으로 변환시켜 응답을 내보냄)
@RestController
public class SampleRestController {

	//@RequestMapping(value="/users", method=RequestMethod.GET)
	@GetMapping(value="/users")	
	public String allUsers() {
		return "all users";
	}

	@PostMapping(value = "/users")	
	public String insertUser() {		
		return "success insert";		
	}
	
}
