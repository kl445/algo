package com.rest.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mybatis.service.CustomerService;
import com.mybatis.vo.Customer;

//Get: http://localhost:8080/rest/customers
//@RestConroller=@Controller +@ResponseBody(java->json으로 변환시켜 응답을 내보냄)
@RestController
public class CustomerRestController {
	
	@Autowired
	CustomerService service;
	
	@GetMapping(value="/customers")	
	public List<Customer> selectAll() {
		return service.selectAll();
	}
	//Get: http://localhost:8080/rest/customers/2
	@GetMapping(value="/customers/{num}")	
	public Customer selectOne(@PathVariable String num) {
		return service.selectOne(num);
	}
	
	//client가 보낸 json 형식으로 보낸 데이터를 java로 변환해서 받아야함
	@PostMapping(value="/customers")
	public String insert(@RequestBody Customer c) {
		service.insert(c);
		
		return "success insert";
	}
	
	
		@DeleteMapping(value="/customers/{num}")	
		public String delete(@PathVariable String num) {
			 service.delete(num);
			 return "delete success";
		}
		
		@RequestMapping(value = "/customers", 
				  method=RequestMethod.PUT)
		public String update(@RequestBody Customer c) {
			service.update(c);
			return "update success";
		  
		}
		
		//http://localhost8080/rest/customers/name/tom
		//http://localhost8080/rest/customers/address/la
		@GetMapping(value="/customers/{condition}/{value}")	
		public List<Customer> search(@PathVariable String condition, @PathVariable String value) {
			
			Map<String, String> map=new HashMap<>();
			
			map.put("condition", condition);	//조건
			map.put("value", value);			//검색어
			
			return service.search(map);
		}
		
		
		
		
		//Get: http://localhost:8080/rest/customers/2
		
		/*@GetMapping(value="/customers/{condition}/{value}")	
		public List<Customer> findByAddress(@PathVariable String condition, @PathVariable String value) {
			
			
			if(condition.equals("address")) {
				return service.findByAddress(value);
			}
			else {
//				return service.findbyName(value);
				return null;
			}
			
			
		}*/
		
	
	
}
