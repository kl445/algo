package com.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mybatis.service.BoardService;
import com.mybatis.vo.Board;

//Get: http://localhost:8080/rest/customers
//@RestConroller=@Controller +@ResponseBody(java->json으로 변환시켜 응답을 내보냄)
@RestController
public class BoardRestController {

	@Autowired
	BoardService service;

	@GetMapping(value = "/board")
	public List<Board> selectAll() {
		return service.selectAll();
	}

	// Get: http://localhost:8080/rest/customers/2
	@GetMapping(value = "/board/{num}")
	public Board selectOne(@PathVariable String num) {
		service.countUp(num);
		return service.selectOne(num);
	}

	// client가 보낸 json 형식으로 보낸 데이터를 java로 변환해서 받아야함
	@PostMapping(value = "/board")
	public String insert(@RequestBody Board b) {
		service.insert(b);

		return "success insert";
	}

	@DeleteMapping(value = "/board/{num}")
	public String delete(@PathVariable String num) {
		service.delete(num);
		return "delete success";
	}

	@RequestMapping(value = "/board", method = RequestMethod.PUT)
	public String update(@RequestBody Board b) {
		service.update(b);
		return "update success";

	}

	@GetMapping(value = "/board/{condition}/{value}")
	public List<Board> findByCondition(@PathVariable String condition, @PathVariable String value) {

		if (condition.equals("title")) {
			return service.findByTitle(value);
		} else {
			return service.findByName(value);
		}

	}
//	@GetMapping(value = "/board/count")
//	public void countUp(@PathVariable String num) {
//		service.countUp(num);
//	}

}
