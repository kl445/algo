package com.mybatis.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mybatis.mapper.CustomerMapper;
import com.mybatis.vo.Customer;
//5.DAO(CRUD) . Repository 객체
@Repository
public class CustomerDAOImpl implements CustomerDAO{
	//java Mapper. auto-inject
	@Autowired   
	CustomerMapper mapper;
	
	@Override
	public List<Customer> selectAll() {	
		return mapper.selectAll();
	}

	@Override
	public Customer selectOne(String num) {
		
		return mapper.selectOne(num);
	}

	//@Transactional
	@Override
	public void insert(Customer c) {
		mapper.insert(c);		
	}

	@Override
	public void delete(String num) {		
		mapper.delete(num);
	}

	@Override
	public void update(Customer c) {		
		mapper.update(c);
	}

	@Override
	public List<Customer> findByAddress(String address) {
		
		return mapper.findByAddress(address);
	}

	@Override
	public List<Customer> search(Map<String, String> map) {
		
		return mapper.search(map);
	}

	


}







