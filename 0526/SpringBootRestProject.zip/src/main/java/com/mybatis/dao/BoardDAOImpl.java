package com.mybatis.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mybatis.mapper.BoardMapper;
import com.mybatis.vo.Board;

//5.DAO(CRUD) . Repository 객체
@Repository
public class BoardDAOImpl implements BoardDAO{
	//java Mapper. auto-inject
	@Autowired   
	BoardMapper mapper;
	
	@Override
	public List<Board> selectAll() {	
		return mapper.selectAll();
	}

	@Override
	public Board selectOne(String num) {
		
		return mapper.selectOne(num);
	}

	//@Transactional
	@Override
	public void insert(Board b) {
		mapper.insert(b);		
	}

	@Override
	public void delete(String num) {		
		mapper.delete(num);
	}

	@Override
	public void update(Board b) {		
		mapper.update(b);
	}

	@Override
	public List<Board> findByTitle(String title) {
		
		return mapper.findByTitle(title);
	}

	@Override
	public List<Board> findByName(String name) {
		
		return mapper.findByName(name);
	}

	@Override
	public void countUp(String num) {
		 mapper.countUp(num);
		
	}


	


}







