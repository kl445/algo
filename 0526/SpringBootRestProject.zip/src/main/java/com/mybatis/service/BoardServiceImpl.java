package com.mybatis.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mybatis.dao.BoardDAO;
import com.mybatis.dao.CustomerDAO;
import com.mybatis.vo.Board;
import com.mybatis.vo.Customer;

//3.Service 객체
@Service
public class BoardServiceImpl implements BoardService {
	//dao auto-inject
	
	@Autowired
	BoardDAO dao;
	
	@Override
	public List<Board> selectAll() {
		return dao.selectAll();
	}

	@Override
	public Board selectOne(String num) {
		return dao.selectOne(num);
	}

	@Transactional
	@Override
	public void insert(Board b) {
		dao.insert(b);
		
	}

	@Override
	public void delete(String num) {
		
		dao.delete(num);
	}

	@Override
	public void update(Board b) {
	
		dao.update(b);
	}



	@Override
	public List<Board> findByTitle(String title) {
		// TODO Auto-generated method stub
		return dao.findByTitle(title);
	}

	@Override
	public List<Board> findByName(String name) {
		// TODO Auto-generated method stub
		return dao.findByName(name);
	}

	@Override
	public void countUp(String num) {
		dao.countUp(num);
		
	}


	
	
}
