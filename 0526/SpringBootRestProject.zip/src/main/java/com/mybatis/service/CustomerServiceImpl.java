package com.mybatis.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mybatis.dao.CustomerDAO;
import com.mybatis.vo.Customer;

//3.Service 객체
@Service
public class CustomerServiceImpl implements CustomerService {
	//dao auto-inject
	
	@Autowired
	CustomerDAO dao;
	
	@Override
	public List<Customer> selectAll() {
		return dao.selectAll();
	}

	@Override
	public Customer selectOne(String num) {
		return dao.selectOne(num);
	}

	@Transactional
	@Override
	public void insert(Customer c) {
		dao.insert(c);
		
	}

	@Override
	public void delete(String num) {
		
		dao.delete(num);
	}

	@Override
	public void update(Customer c) {
	
		dao.update(c);
	}

	@Override
	public List<Customer> findByAddress(String address) {		
		return dao.findByAddress(address);
	}

	@Override
	public List<Customer> search(Map<String, String> map) {
		return dao.search(map); 
		
	}
	
	
}
