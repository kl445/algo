package hw0413;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Product")
public class Product extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("utf-8");
		
		response.setContentType("text/html; charset=utf-8");
		PrintWriter out=response.getWriter();
		
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String explain=request.getParameter("explain");
		String seller=request.getParameter("seller");
		
		
		out.println("<html><body>");
		out.println("<h1>상품을 등록 해 주세요. </h1><br>");
		out.println("상품명: "+ name +"<br>");
		out.println("상품가격: "+ price +"<br>");
		out.println("상품설명: "+ explain +"<br>");
		out.println("판매자: "+ seller +"<br>");
		out.println("</body></html>");
	
	}

}
