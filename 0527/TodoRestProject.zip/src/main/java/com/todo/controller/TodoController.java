package com.todo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mybatis.service.TodoService;
import com.mybatis.vo.Todo;

@CrossOrigin(origins= {"*"},maxAge=6000)
@RestController
public class TodoController {
	
	//service 자동주입
	@Autowired
	TodoService service;
	
	@GetMapping("/todo")
	public List<Todo>allList(){
		
		return service.allList();
	}
	
	@GetMapping("/todo/{condition}/{value}")
	public List<Todo>find(@PathVariable String condition,@PathVariable String value){
		
		System.out.println("condition: "+condition+" value: "+value);
		Map<String, String>map=new HashMap<String, String>();
		map.put(condition, value);

		return service.find(map);
	}
	
	@PostMapping("/todo")
	public boolean add(@RequestBody Todo todo) {
		return service.add(todo);
	}
	
	@PutMapping("/todo")
	public boolean modify(@RequestBody Todo todo) {
		return service.modify(todo);
	}
	
	@DeleteMapping("/todo/{condition}/{value}")
	public boolean delete(@PathVariable String condition,@PathVariable String value) {
		Map<String,String> map=new HashMap<String, String>();
		map.put(condition, value);
		return service.delete(map);
	}
	
	@PutMapping("/todo/{num}")
	public boolean complete(@PathVariable int num) {
		return service.complete(num);
	}
	

}
