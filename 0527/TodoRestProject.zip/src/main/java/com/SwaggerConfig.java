package com;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {
	//http://localhost:8070/swagger-ui.html#/
	private static final Logger logger = LoggerFactory.getLogger(SwaggerConfig.class);
	@Bean
	public Docket todo() {
		
		return new Docket(DocumentationType.SPRING_WEB)
				.groupName("Todo Management")	
				.apiInfo(info())
				.select()//
				.apis(RequestHandlerSelectors.basePackage("com.todo.controller"))				
				.paths(PathSelectors.ant("/rest/**"))
				.build();
 
	}

	private ApiInfo info() {
		return new ApiInfoBuilder().title("Todo Management API")
				.description("<h1>Todo Management</h1>")
				.license("Todo	")
				.version("2.22")
				.build();
	}
}
