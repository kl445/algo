package com.mybatis.vo;

public class Todo {

	int num;
	String todo;
	String id;
	String wdate;
	String edate;
	String done;
	
	
	
	public Todo() {

	}
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getTodo() {
		return todo;
	}
	public void setTodo(String todo) {
		this.todo = todo;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getWdate() {
		return wdate;
	}
	public void setWdate(String wdate) {
		this.wdate = wdate;
	}
	public String getEdate() {
		return edate;
	}
	public void setEdate(String edate) {
		this.edate = edate;
	}
	public String getDone() {
		return done;
	}
	public void setDone(String done) {
		this.done = done;
	}
	public Todo(int num, String todo, String id, String wdate, String edate, String done) {
		super();
		this.num = num;
		this.todo = todo;
		this.id = id;
		this.wdate = wdate;
		this.edate = edate;
		this.done = done;
	}
	
	
	
}
