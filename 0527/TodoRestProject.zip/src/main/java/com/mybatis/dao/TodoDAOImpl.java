package com.mybatis.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mybatis.mapper.TodoMapper;
import com.mybatis.vo.Todo;

@Repository
public class TodoDAOImpl implements TodoDAO {
	
	@Autowired
	TodoMapper mapper;

	@Override
	public List<Todo> allList() {
		return mapper.allList();
	}

	@Override
	public List<Todo> find(Map<String, String> map) {
		return mapper.find(map);
	}

	@Override
	public boolean add(Todo todo) {
		return mapper.add(todo);

	}

	@Override
	public boolean modify(Todo todo) {
		return mapper.modify(todo);
	}

	@Override
	public boolean delete(Map<String, String> map) {
		return mapper.delete(map);
	}

	@Override
	public boolean complete(int num) {
		return mapper.complete(num);
	}
	

}
