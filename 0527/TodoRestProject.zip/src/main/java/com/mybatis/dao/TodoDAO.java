package com.mybatis.dao;

import java.util.List;
import java.util.Map;

import com.mybatis.vo.Todo;

public interface TodoDAO {
	
	List<Todo> allList();//모든 할일 목록
//	List<Todo> findByUser(String id);//사용자 id기준 할일 검색
//	Todo findByNum(int num);//번호기준 할일 검색
	
	List<Todo> find(Map<String, String> map);//번호기준 할일 검색

	boolean add(Todo todo);//할일 등록
	boolean modify(Todo todo);//할일 수정
	
	boolean delete(Map<String, String> map);//할일 삭제
	

	
	boolean complete(int num);//번호기준 완료 여부 변경(N -> Y)
}

