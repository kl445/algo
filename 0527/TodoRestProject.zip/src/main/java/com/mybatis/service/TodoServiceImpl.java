package com.mybatis.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mybatis.dao.TodoDAO;
import com.mybatis.vo.Todo;

@Service
public class TodoServiceImpl implements TodoService {

	@Autowired
	TodoDAO dao;
	
	@Override
	public List<Todo> allList() {
		return dao.allList();
	}

	@Override
	public List<Todo> find(Map<String, String> map) {
		return dao.find(map);
	}

	@Override
	public boolean add(Todo todo) {
		return dao.add(todo);
	}

	@Override
	public boolean modify(Todo todo) {
		return dao.modify(todo);
	}

	@Override
	public boolean delete(Map<String, String> map) {
		return dao.delete(map);
	}

	@Override
	public boolean complete(int num) {
		return dao.complete(num);
	}

}
