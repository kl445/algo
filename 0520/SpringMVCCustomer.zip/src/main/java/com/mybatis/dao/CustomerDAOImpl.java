package com.mybatis.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.mybatis.mapper.CustomerMapper;
import com.mybatis.vo.Customer;
//DAO(CRUD) . Repository ��ü

@Repository
public class CustomerDAOImpl implements CustomerDAO{
	//Mapper. auto-inject
	
	@Autowired
	CustomerMapper mapper;
	
	
	@Override
	public List<Customer> selectAll() {		
		System.out.println(mapper);
		return mapper.selectAll();
	}

	@Override
	public Customer selectOne(String num) {
		
		return mapper.selectOne(num);
	}

	@Override
	public void insert(Customer c) {
				mapper.insert(c);
	}

	@Override
	public void delete(String num) {		
			mapper.delete(num);
	}

	@Override
	public void update(Customer c) {		
		mapper.update(c);
	}

	@Override
	public List<Customer> findByAddress(String address) {
		
		return mapper.findByAddress(address);
	}

	@Override
	public List<Customer> findByName(String name) {
		
		return mapper.findByName(name);
	}


}







