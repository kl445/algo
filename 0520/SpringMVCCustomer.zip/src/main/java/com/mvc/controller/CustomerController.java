package com.mvc.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mybatis.service.CustomerService;
import com.mybatis.vo.Customer;

@Controller
public class CustomerController {
	@Autowired
	CustomerService service;
	
	//@RequestMapping(value = "/list.mvc", method = RequestMethod.GET)
	@GetMapping(value = "/list.mvc")
	public String list(Model model) {
		List<Customer> list = service.selectAll();
		model.addAttribute("list", list);
		return "list";
	}
	
	@GetMapping(value = "/detail.mvc")
	public String detail(Model model, String num) {
		Customer c = service.selectOne(num);
		model.addAttribute("c", c);
		return "detail";
	}
	
	@GetMapping(value = "/insert.mvc")
	public String insert() {//고객 추가 
		return "insert";
	}
	
	
	@PostMapping(value = "/insert.mvc")
	public String insert2(Customer c, Model model) {//데이터 받아와서 db에 insert 
		service.insert(c);
		model.addAttribute("c",c);
		return "sample";
	}
	
	@GetMapping(value = "/delete.mvc")
	public String delete(String num) {
		service.delete(num);
		return "redirect:/list.mvc";
	}
	@GetMapping(value = "/login.mvc")
	public String login() { //로그인 화면
		return "login";
	}
	
	@PostMapping(value = "/login.mvc")
	public String login2(HttpSession session,String id, String pass) {//로그인 처리 session에 저장
		session.setAttribute("id", id);

		return "redirect:/list.mvc";
	}
	
	@GetMapping(value = "/update.mvc")
	public String update(Model model, int num) {//고객 업데이트
		model.addAttribute("num",num);
		return "update";
	}
	
	
	@PostMapping(value = "/update.mvc")
	public String update2(Customer c, Model model) {//데이터 받아와서 db에 업데이트 
		System.out.println("up");
		service.update(c);
		model.addAttribute("c",c);
		System.out.println("down");
		return "detail";
	}
	
	
	@GetMapping(value = "/find.mvc")
	public String find(Model model,String str, String search) {//로그인 처리 session에 저장
		System.out.println(search);
		if(search.equals("address")) {
			model.addAttribute("list",service.findByAddress(str));
			
		}
		else {
			model.addAttribute("list",service.findByName(str));
		}
		
		return "list";
	}
	
}