import UserList from './UserList.js';
import UserDetail from './UserDetail.js';
import UserDelete from './UserDelete.js';



const router=new  VueRouter({
    mode: 'history',
    routes: [

        {
            path:'/top',
            component:{
                template:'<div>최상위 페이지 입니다/</div>'
            }
        },
        {
            path:'/users',
            
            component:  UserList
        },
        {
            path:'/users/delete/:userId',
            name:'userdelete',
            component:UserDelete
        },
        {
            path:'/users/:userId',
            name: 'userdetail',
            component:UserDetail
        }
        // },
        // {
        //     path:'*',
        //     redirect:'/top'
        // }

    ]
})

var app= new Vue({
    el:'#app',
    router
});