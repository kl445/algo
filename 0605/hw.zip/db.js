


var object={
  data : [
        {
          id: 1,
          name: 'Tommy Lee',
          description: '한국에서 일하는 프론트엔드 엔지니어입니다.'
        },
        {
          id: 2,
          name: 'Jane Kim',
          description: '아웃도어, 풋살이 취미인 프로그래머입니다.'
        },
        {
          id: 3,
          name: 'Harry Porter',
          description: '마법이 취미인 데이터 분석가입니다.'
        }
    ]
  }

    export default object ;
    



    