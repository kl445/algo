import userData from './db.js';

export default{


    template:`<div>        
    <div v-if="user">
      <h2>{{ user.name }}님이 삭제 되었습니다.</h2>
       <router-link to="/users">돌아가기</router-link>
    </div>
  </div>`,
    

    data: function(){
        return{
            user:null
        }
    },
    created: function(){
        console.log("dwwd");
        
        
        
        this.deleteData()
    },

    methods:{
        deleteData:function(){
            
            var userId = this.$route.params.userId;
            console.log(this.$route.params.userId);
            console.log(
                "132"
            );
            
            console.log(userId);
            var filteredUsers=userData.data.filter(user =>{
                return userId==user.id
            })
            console.log(filteredUsers);


            if(filteredUsers.length==1){
                this.user=filteredUsers[0];
            }
            console.log(this.user);
            


            filteredUsers=userData.data.filter(user =>{
                return userId!=user.id
            })
            console.log(filteredUsers);
            console.log(userData);
            
            userData.data=filteredUsers;
            console.log(userData);
            

        }
    }




}