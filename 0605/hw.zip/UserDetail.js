import userData from './db.js';
export default{


        template:`<div>        
        <div v-if="user">
        <h2>{{ user.name }}</h2>
        <p>{{ user.description }}</p>
        <a href="#" @click="delCheck()">삭제하기</a>
        
        </div>
        
        </div>`,
//     template:`<div>        
//     <div v-if="user">
//       <h2>{{ user.name }}</h2>
//       <p>{{ user.description }}</p>
//       <a href="#" @click="delCheck({{user.id}})">삭제하기</a>
//     </div>
//   </div>`,
    
    data:function(){
        return{
            user:null
        }
    },
    created:function(){
        console.dir(this)
        this.fetchData()

    },
    watch:{
        '$router':'fetchData'
    },
    methods: {
        fetchData: function () {         
          console.log("@@");
          
          var userId = this.$route.params.userId; //***    
          console.log(userId);
                         
          var filteredUsers = userData.data.filter(function (user) {
        //   var filteredUsers = userData.filter(function (user) {
           return user.id == userId
          })
          console.log(filteredUsers);
          
          
          if(filteredUsers.length == 1)           
              this.user = filteredUsers[0];        
              
              console.log(this.user);
        },
        delCheck(){
            console.log("sd");
            console.log(this.user.id);
            console.log("delcheckend");
            
            
                    if(confirm("삭제?")){
                        this.$router.push({name:'userdelete',params:{userId:this.user.id}});
                    }
                }
            
    }
    // methods:{
    //     fetchData:function(){
            
    //         console.log("DD");
            
    //         var userId=this.$route.param.userId;

    //         var filteredUsers=userData.filter(user=>{
    //             return user.id==userId
    //         })

    //         if(filteredUsers.length==1){
    //             this.user=filteredUsers[0];
    //         }
    //     },
    //     delCheck(userId){
    //         if(confirm("삭제?")){
    //             this.$router.push({path:`/users/delete/${userId}`});
    //         }
    //     }


    // }


}