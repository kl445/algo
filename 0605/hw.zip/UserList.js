
import userData from './db.js';
export default{

    template:`<div>      
    
      <div v-for='user in users'>
        {{user.id}}
        <router-link :to="'/users/'+user.id">{{user.name}}</router-link>
         
      </div>
     
    
  </div>`,
/* <router-link :to="{name:'userdetail',params{userId:user.id}}">{{user.name}}</router-link> */
//   <router-link :to="'/board/' + i">{{i}}번 게시글</router-link>
/* <router-link :to="{name: 'boardview', params: {no: i}}">{{i}}번 게시글</router-link>
<a :href="'#' + i" @click="$router.push({name: 'boardview', params: {no: i}})">{{i}}번 게시글</a>
<router-link :to="'/board/detail/' + i">{{i}}번 게시글</router-link> */ 




//     template:`<div>   
//     <div v-for="user in userData" :key="user.id">
//       {{user.id}}
//      <router-link :to=/users/{{user.id}}>{{ user.name }}</router-link>
//     </div>
//   </div>`,

    // template:'<div>232</div>',

    data(){
        return {
           users: function() {
                return []
           }
        }
    },

    created:function(){
        this.fetchData()
    },
    watch:{
        '$rout': 'fetchData'
    },
    methods:{
        fetchData: function () {   
            // this.users = userData
            console.log(userData);
            console.log(userData.data);
            
            this.users = userData.data
            // console.log(userData)
            // console.dir(this.users);
            // console.log("로그1");
            // console.log(userData);
            // console.log(userData[0].id);
            // console.log(userData[0].name);
            // console.log(userData[0].description);
            // console.log("로그2");
            // console.log(this.users);
            // console.log(this.users[0].id);
            // console.log(this.users[0].name);
            // console.log(this.users[0].description);
          }
        
    }


};