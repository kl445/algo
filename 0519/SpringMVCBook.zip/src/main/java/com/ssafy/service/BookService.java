package com.ssafy.service;

import java.util.List;

import com.ssafy.dto.Book;

public interface BookService {
	public List<Book>  searchAll();
	public Book search(String isbn);
	public void insert(Book book);
	public void update(Book book);
	public void delete(String isbn);
}



