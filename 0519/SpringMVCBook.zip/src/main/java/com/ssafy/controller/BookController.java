package com.ssafy.controller;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ssafy.dto.Book;
import com.ssafy.service.BookService;

@Controller
public class BookController {

	@Autowired
	BookService service;

	@RequestMapping(value = "/list.book", method = RequestMethod.GET)
	public String home(Model model) {
		model.addAttribute("list", service.searchAll());
		return "listBook";
	}

	// http://localhost:8080/book/read.book?isbn=1111
	@RequestMapping(value = "/read.book", method = RequestMethod.GET)
	public String read(Model model, String isbn, HttpServletRequest request) {
		String isbn2 = request.getParameter("isbn");
		model.addAttribute("book", service.search(isbn));
		return "detailBook";
	}

	// http://localhost:8080/book/update.book
	@RequestMapping(value = "/update.book", method = RequestMethod.GET)
	public String update(Model model, String isbn) {
		model.addAttribute("book",service.search(isbn));
		return "updateBook";
	}

	// http://localhost:8080/book/insertinto.book
	@RequestMapping("/updateinto.book")
	public String updateinto(HttpServletRequest request) {

		String isbn = request.getParameter("isbn");
		String title = request.getParameter("title");
		String btype = request.getParameter("catalogue");
		String nation = request.getParameter("nation");
		String publish_date = request.getParameter("publish_date");
		String publisher = request.getParameter("publisher");
		String author = request.getParameter("author");
		String price = request.getParameter("price");
		String currency = request.getParameter("currency");
		String summary = request.getParameter("summary");

		Book book = new Book(isbn, title, publisher, author, Integer.parseInt(price), summary);
		book.setCatalogue(btype);
		book.setNation(nation);
		book.setPublish_date(publish_date);
		book.setCurrency(currency);

		service.update(book);

		return "redirect:/list.book";
	}

	// http://localhost:8080/book/remove.book
	@RequestMapping(value = "/remove.book", method = RequestMethod.GET)
	public String remove(String isbn) {
		service.delete(isbn);
		return "redirect:list.book";
	}

	// http://localhost:8080/book/read.book
	@RequestMapping(value = "/insert.book", method = RequestMethod.GET)
	public String insert() {
		return "insertBook";
	}

	// http://localhost:8080/book/insertinto.book
	@RequestMapping("/insertinto.book")
	public String insertinto(HttpServletRequest request) {

		String isbn = request.getParameter("isbn");
		String title = request.getParameter("title");
		String btype = request.getParameter("catalogue");
		String nation = request.getParameter("nation");
		String publish_date = request.getParameter("publish_date");
		String publisher = request.getParameter("publisher");
		String author = request.getParameter("author");
		String price = request.getParameter("price");
		String currency = request.getParameter("currency");
		String summary = request.getParameter("summary");

		Book book = new Book(isbn, title, publisher, author, Integer.parseInt(price), summary);
		book.setCatalogue(btype);
		book.setNation(nation);
		book.setPublish_date(publish_date);
		book.setCurrency(currency);

		service.insert(book);

		return "redirect:/list.book";
	}

}
