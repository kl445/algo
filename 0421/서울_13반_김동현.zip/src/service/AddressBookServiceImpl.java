package service;

import java.util.ArrayList;

import dao.AddressBookDao;
import dao.AddressBookDaoImpl;
import vo.AddressBook;

public class AddressBookServiceImpl implements AddressBookService {
	AddressBookDao dao;
	
	public AddressBookServiceImpl() {
		dao=new AddressBookDaoImpl();
	}

	@Override
	public ArrayList<AddressBook> selectAll() {
		
		return dao.selectAll();
	}

	@Override
	public AddressBook selectOne(int key) {
		return dao.selectOne(key);
	}

	@Override
	public void insert(AddressBook addressbook) {
		dao.insert(addressbook);

	}

	@Override
	public void delete(int key) {
		dao.delete(key);
	}

	@Override
	public void update(AddressBook addressbook) {
		dao.update(addressbook);
	}

}
