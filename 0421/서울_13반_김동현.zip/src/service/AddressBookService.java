package service;

import java.util.ArrayList;

import vo.AddressBook;

public interface AddressBookService {

	
	public ArrayList<AddressBook> selectAll();
	public AddressBook selectOne(int key);
	public void insert(AddressBook addressbook);
	public void delete(int key);
	public void update(AddressBook addressbook);
}
