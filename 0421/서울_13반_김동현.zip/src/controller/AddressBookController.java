package controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.AddressBookService;
import service.AddressBookServiceImpl;
import vo.AddressBook;

@WebServlet("*.address")
public class AddressBookController extends HttpServlet {
	
	AddressBookService service;
	
	protected void process(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		System.out.println("프로세스진입");
		//service 객체 생성
		service=new AddressBookServiceImpl();
		
		//클라이언트 요청문자
		String reqString=request.getServletPath();
		
		String root=request.getContextPath();
		String path="";
		System.out.println(reqString+"파악");
		
		if(reqString.equals("/list.address")) {
			
			System.out.println(reqString+"진입");
			
			ArrayList<AddressBook> list=service.selectAll();
			
			request.setAttribute("list", list);

			request.getRequestDispatcher("views/list.jsp").forward(request, response);
		}
		else if(reqString.equals("/insertForm.address")) {
			
			System.out.println(reqString+"진입");
			
			request.getRequestDispatcher("views/insertForm.jsp").forward(request, response);
			
		}
		else if(reqString.equals("/insertProcess.address")) {
			
			String name=request.getParameter("name");
			String phone=request.getParameter("phone");
			String address=request.getParameter("address");
			String company=request.getParameter("company");
			
			AddressBook addressbook= new AddressBook(0,name,phone,address,company);
			
			service.insert(addressbook);
			
			request.getRequestDispatcher("views/insertSuccess.jsp").forward(request, response);;
			
		}
		else if(reqString.equals("/read.address")) {
			
			int key=Integer.parseInt(request.getParameter("key"));
			
			AddressBook addressbook=service.selectOne(key);
			
			request.setAttribute("addressbook", addressbook);
			request.getRequestDispatcher("views/read.jsp").forward(request, response);
			
			
		}
		else if(reqString.equals("/delete.address")) {
			
			int key=Integer.parseInt(request.getParameter("key"));
			
			service.delete(key);
			
			response.sendRedirect(root+"/list.address");
			
			
		}
		else if(reqString.equals("/updateForm.address")){
			int key=Integer.parseInt(request.getParameter("key"));
			AddressBook addressbook=service.selectOne(key);
			request.setAttribute("addressbook", addressbook);
			
			request.getRequestDispatcher("views/updateForm.jsp").forward(request, response);;
		}
		else if(reqString.equals("/updateProcess.address")) {
			
			int key=Integer.parseInt(request.getParameter("key"));
			String name=request.getParameter("name");
			String phone=request.getParameter("phone");
			String address=request.getParameter("address");
			String company=request.getParameter("company");
			
			AddressBook addressbook=new AddressBook(key,name,phone,address,company);
			service.update(addressbook);
			
			response.sendRedirect(root+"/list.address");
			
			
			
		}
		
		

		
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		process(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	

}
