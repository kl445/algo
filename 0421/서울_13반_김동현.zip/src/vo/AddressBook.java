package vo;
//레코드 한건의 값 저장
public class AddressBook {
	
	private int key;
	private String name;
	private String phone;
	private String address;
	private String company;
	
	public AddressBook() {
	}

	public AddressBook(int key, String name, String phone, String address, String company) {
		super();
		this.key=key;
		this.name = name;
		this.phone = phone;
		this.address = address;
		this.company = company;
	}
	public int getKey() {
		return key;
	}

	public void setKey(int key) {
		this.key = key;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}
	
	
	
}
