package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import vo.AddressBook;

public class AddressBookDaoImpl implements AddressBookDao {

	ArrayList<AddressBook> list;
	String url = "jdbc:mysql://localhost:3306/harry?serverTimezone=UTC&useUnicode=yes&characterEncoding=UTF-8";
	String user="ssafy";
	String password="ssafy";
	String driver="com.mysql.cj.jdbc.Driver";
	
	//생성자, 리스트 만들기 db 드라이버 호출
	public AddressBookDaoImpl() {
		
		try {
			Class.forName(driver);
			list=new ArrayList<AddressBook>();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	//디비 연결
	public Connection getConnection() {
		Connection con=null;
		
		try {
			con=DriverManager.getConnection(url,user,password);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	
	
	@Override
	public ArrayList<AddressBook> selectAll() {
		
		list.clear(); //리스트 초기화
		Connection con= getConnection();
		String sql="select * from addressbook";
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		try {
			pstmt=con.prepareStatement(sql);
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				int key=rs.getInt(1);
				String name= rs.getString(2);
				String phone=rs.getString(3);
				String address=rs.getString(4);
				String company=rs.getString(5);
				AddressBook addressbook=new AddressBook(key,name,phone,address,company);
				list.add(addressbook);
			}
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("selectall 에러(daoimpl");
		}
		return list;
	}

	@Override
	public AddressBook selectOne(int key) {
		
		Connection con= getConnection();
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="select * from addressbook where id=?";
		AddressBook addressbook=null;
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, key);
			
			rs=pstmt.executeQuery();
			
			while(rs.next()) {
				String name= rs.getString(2);
				String phone=rs.getString(3);
				String address=rs.getString(4);
				String company=rs.getString(5);
				addressbook=new AddressBook(key,name,phone,address,company);
			}
			con.close();
	
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return addressbook;
	}

	@Override
	public void insert(AddressBook addressbook) {
		Connection con=getConnection();
		PreparedStatement pstmt=null;
		
		String sql="insert into addressbook(name,phone,address,company) values(?,?,?,?)";
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, addressbook.getName());
			pstmt.setString(2, addressbook.getPhone());
			pstmt.setString(3, addressbook.getAddress());
			pstmt.setString(4, addressbook.getCompany());
			
			pstmt.executeUpdate();
			
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

	@Override
	public void delete(int key) {
		Connection con=getConnection();
		PreparedStatement pstmt=null;
		String sql="delete from addressbook where id=?";
		
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setInt(1, key);
			pstmt.executeUpdate();
			
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public void update(AddressBook addressbook) {
		Connection con=getConnection();
		PreparedStatement pstmt=null;
		String sql="update addressbook "
				+ "set  name=?, phone=?, address=?, company=?"
				+ "where id=?";
		
		try {
			pstmt=con.prepareStatement(sql);
			pstmt.setString(1, addressbook.getName());
			pstmt.setString(2, addressbook.getPhone());
			pstmt.setString(3, addressbook.getAddress());
			pstmt.setString(4, addressbook.getCompany());
			pstmt.setInt(5, addressbook.getKey());
			pstmt.executeUpdate();
			
			con.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
