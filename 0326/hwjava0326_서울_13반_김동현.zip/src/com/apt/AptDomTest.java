package com.apt;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


//sax parser 생성해서 parsing
public class AptDomTest {

	public static void main(String[] args) throws Exception {

		File file = new File("src/xml/AptDealHistory.xml");

		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();

		// DocumentBuilder: dom parser
		DocumentBuilder parser = factory.newDocumentBuilder();
		Document doc = parser.parse(file); // 파싱된문서의 /
		Element root = doc.getDocumentElement();

		System.out.println("root element: " + root.getNodeName());

//		NodeList list=doc.getElementsByTagName("body");
//		NodeList list2=doc.getElementsByTagName("items");
		NodeList list3 = doc.getElementsByTagName("item");
		List<Apt> elist = new ArrayList<Apt>();

		for (int i = 0; i < list3.getLength(); i++) {
			Node node = list3.item(i);// Employee 1개

			if (node.getNodeType() == Node.ELEMENT_NODE) {
				Element ele = (Element) node;

				String money = ele.getElementsByTagName("거래금액").item(0).getTextContent();
				String dong = ele.getElementsByTagName("법정동").item(0).getTextContent();
				String name = ele.getElementsByTagName("아파트").item(0).getTextContent();

				Apt emp = new Apt();
				emp.setMoney(money);
				emp.setDong(dong);
				;
				emp.setName(name);

				elist.add(emp);
			}
		}

		Scanner sc = new Scanner(System.in);

		System.out.println("아파트 이름 입력:");
		String msg = sc.next();

		for (Apt e : elist) {

			if (e.getName().contains(msg)) {
				System.out.println(e);
			}
		}
	}

}
