package com.apt;

//value object
public class Apt {
    private String money;
    private int build_year;
    private int year;
    private String dong;
    private String name;
    private int month;
    private int day;
    private double area;
    private int branch;
    private int code;
    private int layer;
    
   
    
    public String getMoney() {
    	return money;
    }
	public void setMoney(String money) {
		this.money = money;
	}
	public int getBuild_year() {
		return build_year;
	}
	public void setBuild_year(int build_year) {
		this.build_year = build_year;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public double getArea() {
		return area;
	}
	public void setArea(double area) {
		this.area = area;
	}
	public int getBranch() {
		return branch;
	}
	public void setBranch(int branch) {
		this.branch = branch;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getLayer() {
		return layer;
	}
	public void setLayer(int layer) {
		this.layer = layer;
	}




	@Override
    public String toString() {
    	StringBuilder builder = new StringBuilder();
		builder.append("Apt [거래금액=");
		builder.append(money);
		builder.append(", 법정동=");
		builder.append(dong);
		builder.append(", 아파트=");
		builder.append(name + "]");
		return builder.toString();
    }
    
}
