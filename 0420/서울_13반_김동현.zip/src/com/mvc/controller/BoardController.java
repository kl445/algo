package com.mvc.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mvc.service.BoardService;
import com.mvc.service.BoardServiceImpl;
import com.mvc.vo.Board;

//Controller: 클라이언트로부터 들어오는요청을 받기. 받은 요청을 구분해서 처리
//BoardService에게 작업을 넘김

@WebServlet("*.bod")
public class BoardController extends HttpServlet {
	BoardService service; //interface 타입

	protected void process(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		// service 객체
		service = new BoardServiceImpl();

		//입력창: http://localhost:8080/mvc/list.bod --> /list.bod
		
		// 클라이언트가 보내온 요청문자를 구분
		String reqString = request.getServletPath(); //  -> /list.bod
		String page = "";

		if (reqString.equals("/list.bod")) {//게시판 목록 화면(첫화면)
			ArrayList<Board>list= service.selectAll();
			//jsp로 넘어가기전에 데이터를 저장 (response가 나가면 사라짐)
			request.setAttribute("list", list);
			
			//veiw로 화면을 넘기기(reqeust가 계속 jsp로 전달됨)
			RequestDispatcher rdisp=request.getRequestDispatcher("views/list.jsp");
			rdisp.forward(request, response);
			
		} else if (reqString.equals("/read.bod")) {// 글 한개 읽기 요청
			//글 번호 받아서 처리
			String num=request.getParameter("num");
			Board board=service.selectOne(num);
			request.setAttribute("b", board);
			RequestDispatcher rdisp=request.getRequestDispatcher("/views/read.jsp");
			rdisp.forward(request, response);
			

		} else if (reqString.equals("/insertForm.bod")) {//입력화면 요청
			RequestDispatcher rdisp=
					request.getRequestDispatcher("/views/insert.jsp");
			rdisp.forward(request, response);

		} else if (reqString.equals("/insertProcess.bod")) {//입력한 값을 db에 저장
			//사용자가 입력한 값 받기
			//service에게 넘기기 -> db에 인서트
			//새글 등록 성공 화면 (insertSuccess.jsp)로 forward 하여 만들기 
			//이후 리스트로 연결하는 링크 만들기
			String title=request.getParameter("title");
			String name=request.getParameter("name");
			String pass=request.getParameter("pass");
			String content=request.getParameter("content");
			
			Board b=new Board(null,pass,name,null,title,content,null);
			System.out.println(b);
			service.insert(b);
			System.out.println("service 실행");
			
			RequestDispatcher rdisp=request.getRequestDispatcher("/views/insertSuccess.jsp");
			rdisp.forward(request, response);
			
			
			
		} else if(reqString.equals("/delete.bod")) {//글 삭제
			//삭제할 글번호를 받아 서비스에게 제공
			String num=request.getParameter("num");
			
			service.delete(num);
			
			RequestDispatcher rdisp=request.getRequestDispatcher("/list.bod");
			rdisp.forward(request, response);
		}

		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 클라이언트로부터 들어오는 한글 처리
		request.setCharacterEncoding("utf-8");
		process(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		process(request, response);
	}

}
