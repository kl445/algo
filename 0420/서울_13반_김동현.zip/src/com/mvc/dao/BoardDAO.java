package com.mvc.dao;

import java.util.ArrayList;

import com.mvc.vo.Board;

public interface BoardDAO {
	public ArrayList<Board> selectAll();
	public Board selectOne(String num);
	public void insert(Board b);
	public void delete(String num);
}
