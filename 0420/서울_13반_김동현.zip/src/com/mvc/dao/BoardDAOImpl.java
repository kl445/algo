package com.mvc.dao;
//DAO(Data Access Object): jsp를 위해 db 작업 수행
//Create, Read, Update, Delete

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import com.mvc.service.BoardService;
import com.mvc.vo.Board;
//dao:create, read, update, delete -> CRUD  작업
public class BoardDAOImpl implements BoardDAO{
	
	ArrayList<Board> list;
	String url = "jdbc:mysql://localhost:3306/harry?serverTimezone=UTC&useUnicode=yes&characterEncoding=UTF-8";
	String user = "ssafy";
	String password = "ssafy";	
	String driver = "com.mysql.cj.jdbc.Driver";
	
	//생성자: 객체 생성시에 자동 호출됨	
	public BoardDAOImpl() {
		try {
			Class.forName(driver); // 1
			list = new ArrayList<Board>();			
		} catch (Exception e) {
			e.printStackTrace();
		}	
	}
	
	public Connection getConnection() {//Connection생성해서 리턴
		//2. Connection 생성(Network 연결)
		Connection con = null;
		try {
			con = DriverManager.getConnection(url, user, password);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public ArrayList<Board> selectAll() {
		try {
			list.clear();
			Connection con = getConnection();		
			Statement stat = con.createStatement();	
			String q = "select num,name,wdate,title,count from board order by num desc";
			ResultSet rs = stat.executeQuery(q);
			
			while(rs.next() == true) {
				String num = rs.getString(1);
				String name = rs.getString(2);
				String wdate = rs.getString(3).substring(0, 10);
				String title = rs.getString(4);
				String count = rs.getString(5);
				
				//뽑은 5개의 값을 vo에 저장
				Board b = new Board(num, null,name,wdate,title,null,count);
				list.add(b);
			}
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;		
	}
	
	public Board selectOne(String num) {
		countUp(num);
		
		Board b = null;		
		try {
			
			Connection con = getConnection();				
			String q = "select * from board where num = ?";
			PreparedStatement stat = con.prepareStatement(q);
			stat.setString(1, num);
			
			ResultSet rs = stat.executeQuery();
			
			rs.next();
			num = rs.getString(1);
			String pass = rs.getString(2);
			String name = rs.getString(3);			
			String wdate = rs.getString(4);
			String title = rs.getString(5);
			String content = rs.getString(6);
			String count = rs.getString(7);
			
			//뽑은 5개의 값을 vo에 저장
			b = new Board(num, pass, name,wdate,title,content,count);
					
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return b;		
	}
	
	public void countUp(String num) {//조회수 증가시키는 메소드
		try {
			
			Connection con = getConnection();				
			String q = "update board set count = count + 1 where num = ?";
			PreparedStatement stat = con.prepareStatement(q);
			stat.setString(1, num);
			
			stat.executeUpdate();					
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	@Override
	public void insert(Board b) {
		System.out.println("dao임플");
		try {
			
			Connection con = getConnection();				
			String q = "insert into board(pass,name,wdate,title,content,count) values(?,?,sysdate(),?,?,0)";
			PreparedStatement stat = con.prepareStatement(q);
			stat.setString(1, b.getPass());
			stat.setString(2, b.getName());
			stat.setString(3, b.getTitle());
			stat.setString(4, b.getContent());
			
			stat.executeUpdate();					
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("insert 트라이");
		}
		
	}

	@Override
	public void delete(String num) {
		try {
			Connection con=getConnection();
			String q="delete from board where num=?";
			PreparedStatement stat=con.prepareStatement(q);
			stat.setString(1, num);
			
			stat.executeUpdate();
			con.close();
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
	}
	
	

}










