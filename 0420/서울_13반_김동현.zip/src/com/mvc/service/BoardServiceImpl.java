package com.mvc.service;

import java.util.ArrayList;

import com.mvc.dao.BoardDAO;
import com.mvc.dao.BoardDAOImpl;
import com.mvc.vo.Board;
//controller에서 요청을 받아서 dao에게 넘기는 역할
public class BoardServiceImpl implements BoardService{
	
	BoardDAO dao;
	
	public BoardServiceImpl() {
		dao = new BoardDAOImpl();
	}	
	
	@Override
	public ArrayList<Board> selectAll() {
		return dao.selectAll();
	}

	@Override
	public Board selectOne(String num) {
		return dao.selectOne(num);
	}

	@Override
	public void insert(Board b) {
		dao.insert(b);
		
		System.out.println("서비스 임플");
		
		
	}

	@Override
	public void delete(String num) {	
		dao.delete(num);
		
	}

}
