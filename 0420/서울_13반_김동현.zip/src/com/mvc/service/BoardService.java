package com.mvc.service;

import java.util.ArrayList;

import com.mvc.vo.Board;

public interface BoardService {
	public ArrayList<Board> selectAll();
	public Board selectOne(String num);
	public void insert(Board b);
	public void delete(String num);
}
