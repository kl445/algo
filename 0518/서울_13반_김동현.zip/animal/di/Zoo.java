package com.animal.di;

public interface Zoo {
	
	public void info();

}
