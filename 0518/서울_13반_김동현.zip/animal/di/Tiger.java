package com.animal.di;

public class Tiger implements Animal{

	
	int age;
	String name;
	
	
	public Tiger(int age) {
		super();
		this.age = age;
	}
	
	
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public void info() {
		System.out.println("호랑이");
		System.out.println("이름: "+this.name+" 나이: "+this.age);
		
	}
}
