package com.animal.di;

public class Lion implements Animal{
	
	
	//컨스트럭터(생성자)
	int age;
	//프로펙터(seter)
	String name;
	
	
	
	public Lion(int age) {
		super();
		this.age = age;
	}
	
	
	public void setName(String name) {
		this.name = name;
	}





	@Override
	public void info() {
		System.out.println("사자");
		System.out.println("이름: "+this.name+" 나이: "+this.age);
		
	}


}
