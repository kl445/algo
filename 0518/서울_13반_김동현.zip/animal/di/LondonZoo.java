package com.animal.di;

public class LondonZoo implements Zoo{

	//생성자 주입
	Lion lion;
	//세터 주입
	Tiger tiger;
	
	
	
	public LondonZoo(Lion lion) {
		super();
		this.lion = lion;
	}
	

	public void setTiger(Tiger tiger) {
		this.tiger = tiger;
	}




	@Override
	public void info() {
		System.out.println("런던 동물원");
		lion.info();
		tiger.info();
		
	}
	
	
	
}
