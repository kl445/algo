package com.animal.di;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AnimallApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//컨테이너 생성
		// xml 문서 읽기 animal.xml
		//get Bean 실행 ( london, seoul zoo)
		//info 2번 호출
		//패키지와 xml 압축해서 제출
		
		
		
		ApplicationContext ctxt= new ClassPathXmlApplicationContext("zoo.xml");
		
		Zoo london=ctxt.getBean("londonzoo",Zoo.class);
		Zoo seoul=ctxt.getBean("seoulzoo",Zoo.class);
		
		london.info();
		seoul.info();
		
		
	}

}
