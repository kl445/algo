package com.animal.di;

public class SeoulZoo implements Zoo {
	
	
	Lion lion;
	Tiger tiger;
	
	
	public SeoulZoo(Lion lion) {
		super();
		this.lion = lion;
	}
	

	public void setTiger(Tiger tiger) {
		this.tiger = tiger;
	}
	
	
	@Override
	public void info() {
		System.out.println("서울 동물원");
		lion.info();
		tiger.info();
		
		
	}
	
	

}
