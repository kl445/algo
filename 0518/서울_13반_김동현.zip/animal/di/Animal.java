package com.animal.di;

public interface Animal {

	public void info();
		

}
