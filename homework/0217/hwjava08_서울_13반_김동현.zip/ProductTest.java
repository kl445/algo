package hwjava08;

import java.util.ArrayList;
import java.util.Scanner;



public class ProductTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ProductMgrImpl p= ProductMgrImpl.getInstance();
		Scanner sc= new Scanner(System.in);

		
		
		
		p.add(new TV(125, "올레드티비", 400000, 10, 40));
		p.add(new Refrigerator(456, "올레드냉장고", 500000, 1, 500));
		p.add(new TV(185, "대형티비", 800000, 5, 60));
		p.add(new Refrigerator(325, "미니냉장고", 150000, 3, 100));
		p.add(new TV(395, "대형올레드티비", 1500000, 3, 60));
		
		
		
		ArrayList<Product> temp=new ArrayList<>();
		System.out.println("모두 검색");
		temp=p.total();
		for (Product product : temp) {
			System.out.println(product);
		}
		System.out.println();
		
		System.out.println("상품번호 검색");
		System.out.println(p.findByNum(395));
		System.out.println();
		
		System.out.println("상품이름 검색");
		temp=p.findByName("올레드");
		for (Product product : temp) {
			System.out.println(product);
		}
		System.out.println();
		
		System.out.println("tv검색");
		ArrayList<TV> TVtemp=new ArrayList<>();
			TVtemp=p.findTV();
		for (Product product : TVtemp) {
			System.out.println(product);
		}
		System.out.println();
		
		System.out.println("냉장고검색");
		ArrayList<Refrigerator> Refrigeratortemp=new ArrayList<>();
		Refrigeratortemp=p.findRefrigerator();
		for (Product product : Refrigeratortemp) {
			System.out.println(product);
		}
		System.out.println();
		
		
		System.out.println("400L 이상 냉장고 검색");
		Refrigeratortemp=p.findRefrigeratorUp400();
		for (Product product : Refrigeratortemp) {
			System.out.println(product);
		}
		System.out.println();
		
		System.out.println("50인치 이상 TV검색");
		TVtemp=p.findTVUp50();
		for (Product product : TVtemp) {
			System.out.println(product);
		}
		System.out.println();
		
		System.out.println("특정 넘버의 가격 업데이트");
		p.update(125, 500000);
		System.out.println(p.findByNum(125));
		System.out.println();
		
		System.out.println("특정 넘버의 삭제");
		p.delete(456);
		temp=p.total();
		for (Product product : temp) {
			System.out.println(product);
		}
		System.out.println();
		
		System.out.println("재고 금액 ");
		System.out.println(p.totalStockPrice());
		System.out.println();
	}

}
