package hwjava08;

public class Refrigerator extends Product {
	private int l;

	public Refrigerator(int num, String name, int price, int stock, int l) {
		super(num, name, price, stock);
		this.l = l;
	}

	public int getL() {
		return l;
	}

	public void setL(int l) {
		this.l = l;
	}

	@Override
	public String toString() {
		return super.toString()+ "L=" + l + "]";
	}

}
