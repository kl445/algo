package hwjava08;

import java.util.ArrayList;

public class ProductMgrImpl implements IProductMgr {

	ArrayList<Product> products = new ArrayList<>();

	private ProductMgrImpl() {

	}

	private static ProductMgrImpl instance;

	public static ProductMgrImpl getInstance() {
		if (instance == null) {
			instance = new ProductMgrImpl();
		}
		return instance;
	}

	@Override
	public void add(Product product) {
		// TODO Auto-generated method stub

		products.add(product);

	}

	@Override
	public ArrayList<Product> total() {
		// TODO Auto-generated method stub
		ArrayList<Product> temp = new ArrayList<>();

		for (Product product : products) {
			temp.add(product);
		}
		return temp;
	}

	@Override
	public Product findByNum(int num) {
		// TODO Auto-generated method stub

		for (Product product : products) {
			if (product.getNum() == num) {
				return product;
			}

		}

		return null;
	}

	@Override
	public ArrayList<Product> findByName(String name) {
		// TODO Auto-generated method stub
		ArrayList<Product> temp = new ArrayList<>();

		for (Product product : products) {
			if (product.getName().contains(name)) {
				temp.add(product);
			}
		}
		return temp;
	}

	@Override
	public ArrayList<TV> findTV() {
		// TODO Auto-generated method stub
		ArrayList<TV> temp = new ArrayList<>();

		for (Product product : products) {
			if (product instanceof TV) {
				temp.add((TV) product);
			}
		}
		return temp;
	}

	@Override
	public ArrayList<Refrigerator> findRefrigerator() {
		ArrayList<Refrigerator> temp = new ArrayList<>();

		for (Product product : products) {
			if (product instanceof Refrigerator) {
				temp.add((Refrigerator) product);
			}
		}
		return temp;
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Refrigerator> findRefrigeratorUp400() {
		// TODO Auto-generated method stub
		ArrayList<Refrigerator> temp = new ArrayList<>();

		for (Product product : products) {
			if (product instanceof Refrigerator) {
				if(((Refrigerator)product).getL()>=400)
				temp.add((Refrigerator) product);
			}
		}
	
		return temp;
	}

	@Override
	public ArrayList<TV> findTVUp50() {
		ArrayList<TV> temp = new ArrayList<>();
		for (Product product : products) {
			if (product instanceof TV) {
				if(((TV)product).getInch()>=50)
				temp.add((TV) product);
			}
		}
	
		return temp;
	}

	@Override
	public void update(int num, int price) {

		for (Product product : products) {
			if(product.getNum()==num) {
				product.setPrice(price);
			}
		}

		
	}
	@Override
	public void delete(int num) {
		// TODO Auto-generated method stub
		
		int index=0;
		int del=0;
		for (Product product : products) {
			if(product.getNum()==num) {
				del=index;
				
			}
			index++;
		}
		products.remove(del);
		
	}

	
	@Override
	public int totalStockPrice() {
		int totalPrice=0;
		
		for (Product product : products) {
			totalPrice+=product.getPrice()*product.getStock();
		}
		return totalPrice;
	}

}
