package hwjava08;

import java.util.ArrayList;

public interface IProductMgr {
	
	public void add(Product product);
	
	public ArrayList<Product> total();
	
	public Product findByNum(int num);
	
	public ArrayList<Product> findByName(String name);
	
	public ArrayList<TV> findTV();
	
	public ArrayList<Refrigerator> findRefrigerator();
	
	public ArrayList<Refrigerator> findRefrigeratorUp400();
	
	public ArrayList<TV> findTVUp50();
	
	public void update(int num, int price);
	
	public void delete(int num);
	
	public int totalStockPrice();
}
