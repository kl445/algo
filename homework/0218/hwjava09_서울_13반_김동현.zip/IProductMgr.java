package hwjava09;

import java.util.ArrayList;

class CodeNotFoundException extends Exception{
	String msg;

	public CodeNotFoundException(String msg) {
		this.msg = msg;
	}

	@Override
	public String toString() {
		return "CodeNotFoundException [msg=" + msg + "]";
	}
	
}
class DuplicateException extends Exception{
	String msg;
	
	public DuplicateException(String msg) {
		this.msg = msg;
	}
	
	@Override
	public String toString() {
		return "DuplicateException [msg=" + msg + "]";
	}
	
}

class ProductNotFoundException extends Exception{
	String msg;
	
	public ProductNotFoundException(String msg) {
		this.msg = msg;
	}
	
	@Override
	public String toString() {
		return "ProductNotFoundException [msg=" + msg + "]";
	}
	
}


public interface IProductMgr {
	
	public void add(Product product) throws DuplicateException  ;
	
	public ArrayList<Product> total();
	
	public Product findByNum(int num) throws CodeNotFoundException;
	
	public ArrayList<Product> findByName(String name);
	
	public ArrayList<TV> findTV();
	
	public ArrayList<Refrigerator> findRefrigerator();
	
	public ArrayList<Refrigerator> findRefrigeratorUp400() throws ProductNotFoundException;
	
	public ArrayList<TV> findTVUp50() throws ProductNotFoundException;
	
	public void update(int num, int price);
	
	public void delete(int num);
	
	public int totalStockPrice();
	
	public void open() throws Exception;
	
	public void close() throws Exception;
}
