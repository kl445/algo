package hwjava09;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

import wsjava_09.Book;
import wsjava_09.Magazine;

public class ProductMgrImpl implements IProductMgr {

	ArrayList<Product> products ;

	private ProductMgrImpl() {
		products= new ArrayList<>();
		
		System.out.println("오픈");
		try {
		open();
		}
		catch(Exception e){
			System.out.println(e);
			System.out.println("없음");
			
		}

	}

	private static ProductMgrImpl instance;

	public static ProductMgrImpl getInstance() {
		if (instance == null) {
			instance = new ProductMgrImpl();
		}
		return instance;
	}

	@Override
	public void add(Product product) throws DuplicateException{
		// TODO Auto-generated method stub

		for (Product pro : products) {
			if(pro.getNum()==product.getNum()) {
				throw new DuplicateException("중복된 제품");
			}
		}
		products.add(product);

	}

	@Override
	public ArrayList<Product> total() {
		// TODO Auto-generated method stub
		ArrayList<Product> temp = new ArrayList<>();

		for (Product product : products) {
			temp.add(product);
		}
		return temp;
	}

	@Override
	public Product findByNum(int num) throws CodeNotFoundException {
		// TODO Auto-generated method stub
		boolean flag= false;
		for (Product product : products) {
			
			if (product.getNum() == num) {
				return product;
			}

		}
		
		if(!flag) {
			throw new CodeNotFoundException("없는 번호 입니다");
		}

		return null;
	}

	@Override
	public ArrayList<Product> findByName(String name) {
		// TODO Auto-generated method stub
		ArrayList<Product> temp = new ArrayList<>();

		for (Product product : products) {
			if (product.getName().contains(name)) {
				temp.add(product);
			}
		}
		return temp;
	}

	@Override
	public ArrayList<TV> findTV() {
		// TODO Auto-generated method stub
		ArrayList<TV> temp = new ArrayList<>();

		for (Product product : products) {
			if (product instanceof TV) {
				temp.add((TV) product);
			}
		}
		return temp;
	}

	@Override
	public ArrayList<Refrigerator> findRefrigerator() {
		ArrayList<Refrigerator> temp = new ArrayList<>();

		for (Product product : products) {
			if (product instanceof Refrigerator) {
				temp.add((Refrigerator) product);
			}
		}
		return temp;
		// TODO Auto-generated method stub
		
	}

	@Override
	public ArrayList<Refrigerator> findRefrigeratorUp400() throws ProductNotFoundException{
		// TODO Auto-generated method stub
		ArrayList<Refrigerator> temp = new ArrayList<>();

		boolean flag=false;
		for (Product product : products) {
			if (product instanceof Refrigerator) {
				if(((Refrigerator)product).getL()>=400)
				temp.add((Refrigerator) product);
				flag=true;
			}
		}
		
		if(!flag) {
			throw new ProductNotFoundException("해당하는 물건이 없습니다.");
		}
	
		return temp;
	}

	@Override
	public ArrayList<TV> findTVUp50()  throws ProductNotFoundException{
		ArrayList<TV> temp = new ArrayList<>();
		
		boolean flag=false;
		for (Product product : products) {
			if (product instanceof TV) {
				if(((TV)product).getInch()>=50)
				temp.add((TV) product);
				flag=true;
			}
		}
		if(!flag) {
			throw new ProductNotFoundException("해당하는 물건이 없습니다.");
		}
	
		return temp;
	}

	@Override
	public void update(int num, int price) {

		for (Product product : products) {
			if(product.getNum()==num) {
				product.setPrice(price);
			}
		}

		
	}
	@Override
	public void delete(int num) {
		// TODO Auto-generated method stub
		
		int index=0;
		int del=0;
		for (Product product : products) {
			if(product.getNum()==num) {
				del=index;
				
			}
			index++;
		}
		products.remove(del);
		
	}

	
	@Override
	public int totalStockPrice() {
		int totalPrice=0;
		
		for (Product product : products) {
			totalPrice+=product.getPrice()*product.getStock();
		}
		return totalPrice;
	}
	
	@Override
	public void open() throws Exception {
		// TODO Auto-generated method stub

		FileInputStream fis = new FileInputStream("src\\hwjava09\\product.dat"); // node stream
		ObjectInputStream ois = new ObjectInputStream(fis); // filter stream

		ArrayList<Product> temp = (ArrayList<Product>) ois.readObject();

		if (temp.size() >0) {
			System.out.println("if");
			products.addAll(temp);
		}else {
			System.out.println("else");
			products.add(new TV(125, "올레드티비", 400000, 10, 40));
			products.add(new Refrigerator(456, "올레드냉장고", 500000, 1, 500));
			products.add(new TV(185, "대형티비", 800000, 5, 60));
			products.add(new Refrigerator(325, "미니냉장고", 150000, 3, 100));
			products.add(new TV(395, "대형올레드티비", 1500000, 3, 60));
		}

		ois.close();
		fis.close();

	}

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub

		FileOutputStream fos = new FileOutputStream("src\\hwjava09\\product.dat"); // node stream
		ObjectOutputStream oos = new ObjectOutputStream(fos); // filter stream

		oos.writeObject(products);

		oos.close();
		fos.close();

	}

}
