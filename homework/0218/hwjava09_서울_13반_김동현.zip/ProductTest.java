package hwjava09;

import java.util.ArrayList;
import java.util.Scanner;

public class ProductTest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		ProductMgrImpl p = ProductMgrImpl.getInstance();
		Scanner sc = new Scanner(System.in);

		try {
			p.add(new TV(395, "대형올레드티비", 1500000, 3, 60));
		} catch (Exception e) {
			System.out.println(e);
		}

		ArrayList<Product> temp = new ArrayList<>();
		System.out.println("모두 검색");
		temp = p.total();
		for (Product product : temp) {
			System.out.println(product);
		}
		System.out.println();

		System.out.println("상품번호 검색");
		try {
			System.out.println(p.findByNum(395));
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println();

		System.out.println("상품번호 검색2");
		try {
			System.out.println(p.findByNum(15555));
		} catch (Exception e) {
			System.out.println(e);
		}
		System.out.println();

		ArrayList<TV> TVtemp = new ArrayList<>();
		ArrayList<Refrigerator> Refrigeratortemp = new ArrayList<>();

		System.out.println("400L 이상 냉장고 검색");
		try {
			Refrigeratortemp = p.findRefrigeratorUp400();
		} catch (Exception e) {
			System.out.println(e);
		}
		for (Product product : Refrigeratortemp) {
			System.out.println(product);
		}
		System.out.println();

		System.out.println("50인치 이상 TV검색");
		try {
			TVtemp = p.findTVUp50();
		} catch (Exception e) {
			System.out.println(e);
		}
		for (Product product : TVtemp) {
			System.out.println(product);
		}
		System.out.println();

		p.close();
	}

}
