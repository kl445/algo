<template>
  <div id="app">
    <todo-header></todo-header> 
    <todo-input v-on:addTodo='addTodo'></todo-input>
    <todo-list :todoItems="todoItems" ></todo-list>
    <todo-footer v-on:clear='clear'></todo-footer>

    
  </div>
</template>

<script>
import TodoHeader from './components/TodoHeader.vue'
import TodoList from './components/TodoList.vue'
import TodoFooter from './components/TodoFooter.vue'
import TodoInput from './components/TodoInput.vue'


export default {
  name: 'App',
  components: {
    TodoHeader,
    TodoList,
    TodoFooter,
    TodoInput
  },
  data(){
        return{
            todoItems:[], //localstoreage에서 값을 읽어옴
            
        }
    },
    created(){
        this.getTodoList();
    },
    methods:{
      addTodo(newItem){
            //값을 local storage에 저장
            if(newItem!=''){
                localStorage.setItem(newItem,newItem);
            }
            console.log("update");
            
            this.getTodoList();
        },
        getTodoList(){
            this.todoItems=[];
            if(localStorage.length>0){
                for(var i=0; i<localStorage.length;i++){
                    var val=localStorage.getItem(localStorage.key(i));  //i번째 키에 해당하는 값
                    
                    this.todoItems.push(val)
                }
            }
            console.log(this.todoItems);
            
        },
        
        clear (){
        console.log("clear");
         //
            localStorage.clear();
            // this.todoItems.clear(); //배열의 index위치에서 삭제
            this.getTodoList();
         }
    }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
