<template>
    <header>
        <img src="@/assets/logo.png">
        <h1>Todo It!!!!</h1>
    </header>
</template>

<script>
export default {

}
</script>

<style scoped>
h1 {
  color: #2f3b52;
  font-weight: 900;
  margin: 2.5rem 0 1.5rem;
}
</style>

4.TodoInput
<style scoped>
h1{
    color:coral
}
input:focus {
  outline: none;
}
.inputBox {
  background: white;
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}

.addBtn {
  color: blueviolet;
  vertical-align: middle;
}
</style>