<template>
    <div class="inputBox">
        <!-- <h1>TodoInput</h1><br><br><br> -->
        할일 입력:<input calss="inputBox input" type="text" @keyup.enter="addTodo" v-model="todoItem">
        <button class="addBtn" @click="addTodo">추가</button>
    </div>
</template>

<script>
export default {
    data(){
        return{
            todoItem:'' //입력값이 들어옴
        }
    },

    methods:{
        addTodo(){
            console.log(this.todoItem);
            
            this.$emit('addTodo',this.todoItem)
            //값을 local storage에 저장
            // if(this.todoItem!=''){
            //     localStorage.setItem(this.todoItem,this.todoItem);
            //     this.clear();
            // }
        },
        clear(){
            this.todoItem=''; //화면도 지워짐
        }
    }
}
</script>

<style scoped>
input:focus {
  outline: none;
}
.inputBox {
  background: rgb(163, 129, 129);
  height: 50px;
  line-height: 50px;
  border-radius: 5px;
}
.inputBox input {
  border-style: none;
  font-size: 0.9rem;
}

.addBtn {
  color: blueviolet;
  vertical-align: middle;
}
</style>