<template>
  <div>
      <h1> 리스트시작</h1>
      <ul>
            <li v-for="(todoItem,index) in todoItems" v-bind:key="todoItem">
              {{index+1}} : {{todoItem}}
           

                <span class="removeBtn" type="button" @click="removeTodo(index)">
                    <i class="far fa-trash-alt">delete</i>
                </span>         
             </li> 
      </ul>
  </div>
</template>

<script>
export default {
    props:['todoItems'],

    methods:{
      removeTodo(index){
            console.log("romove_app");
            
            //localstorage에서 삭제 && 배열에서 삭제
            localStorage.removeItem(localStorage.key(index));
            this.todoItems.splice(index,1); //배열의 index위치에서 삭제 

            
        },
    }

}
</script>

<style scoped>
ul {
  list-style-type: none;
  padding-left: 0px;
  margin-top: 0;
  text-align: left;
}
li {
  display: flex;
  min-height: 50px;
  height: 50px;
  line-height: 50px;
  margin: 0.5rem 0;
  padding: 0 0.9rem;
  background: white;
  border-radius: 5px;
}
.checkBtn {
  line-height: 45px;
  color: #62acde;
  margin-right: 5px;
}
.removeBtn {
  margin-left: auto;
  color: #de4343;
}

.list-item {
  display: inline-block;
  margin-right: 10px;
}
.list-move {
  transition: transform 1s;
}
.list-enter-active,
.list-leave-active {
  transition: all 1s;
}
.list-enter,
.list-leave-to {
  opacity: 0;
  transform: translateY(30px);
}
.done{
  background-color: lightslategray;
}
</style>