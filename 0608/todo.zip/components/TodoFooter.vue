<template>
  
  <button class="clearAllBtn" @click="clear">clear</button>
</template>

<script>
export default {

  methods:{
    clear: function(){
      this.$emit('clear');
    }
  }
}
</script>

<style scoped>
  .clearAllContainer {
    width: 8.5rem;
    height: 50px;
    line-height: 50px;
    background-color: white;
    border-radius: 5px;
    margin: 0 auto;
  }
  .clearAllBtn {
    color: #e20303;
    display: block;
  }
</style>