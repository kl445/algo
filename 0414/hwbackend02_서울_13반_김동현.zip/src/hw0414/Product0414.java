package hw0414;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Product0414")
public class Product0414 extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		request.setCharacterEncoding("utf-8");
		
		
		String name=request.getParameter("name");
		String price=request.getParameter("price");
		String explain=request.getParameter("explain");
		String seller=request.getParameter("seller");
		
		ProductDto product=new ProductDto(name,price,explain,seller);
		
		request.setAttribute("product", product);
		
		RequestDispatcher dis=request.getRequestDispatcher("/0414/product_print.jsp");
		dis.forward(request, response);
		
	
	}

}
